# Hostel-Management-system1
About hostel management in the universities1
